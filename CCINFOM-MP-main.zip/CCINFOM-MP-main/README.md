# CCINFOM-MP

## Notes
- self-study na yung java part...so hopefully matutunan niyo in your free time especially since at least half the group didn't take prog3 TT
- https://www.youtube.com/watch?v=9ntKSLLDeSs i used this video to setup jconnector
- LOAD MYSQL FILE INTO WORKBENCH SYSTEM BEFORE RUNNING JAVA PROGRAM

## Files
- `sql/Group8_DB.sql`: MySQL loading file, import first before testing java app
- `src/Main.java`: main java file, used for running program
- `src/Utilities.java`: for storing helper functions (user input, parsers, etc)
- `src/RestaurantRecordsMgt.java`: logic for viewing items in tables
- `src/RestaurantTransactions.java`: logic for adding/editing items in tables
- `src/RestaurantReports.java`: logic for displaying time dated reports